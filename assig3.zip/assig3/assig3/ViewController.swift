//
//  ViewController.swift
//  assig5
//
//  Created by Гаухар Уалиева on 2/7/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstView: UIView!
    @IBOutlet weak var secondView: UIView!
    
    @IBOutlet weak var segmentController: UISegmentedControl!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        firstView.isHidden = false
        secondView.isHidden = true
    }
    @IBAction func changeLayout(_ sender: UISegmentedControl) {
        if secondView.isHidden{
            firstView.isHidden = true
            secondView.isHidden = false
        }else{
            firstView.isHidden = false
            secondView.isHidden = true 
        }
    }
    

}

